(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var cardBg = style.getPropertyValue('--card-bg').trim();

  // --- Chart 1: Volume Growth ---
  var chart1 = echarts.init(document.getElementById('chart-volume-growth'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      backgroundColor: 'rgba(15, 23, 42, 0.95)',
      borderColor: rule,
      borderWidth: 1,
      textStyle: { color: ink, fontSize: 13 },
      formatter: function(params) {
        var p = params[0];
        return p.axisValue + '<br/>交易量：<strong style="color:' + accent + '">' + p.value + '亿美元</strong>';
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['2023年', '2024年', '2025年', '2026年(预估)'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 12 },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '交易量（亿美元）',
      nameTextStyle: { color: muted, fontSize: 12 },
      axisLine: { show: false },
      axisLabel: { color: muted, fontSize: 12 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [{
      type: 'bar',
      data: [20, 90, 440, 1000],
      itemStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: accent },
            { offset: 1, color: accent2 }
          ]
        },
        borderRadius: [6, 6, 0, 0]
      },
      barWidth: '50%',
      label: {
        show: true,
        position: 'top',
        color: ink,
        fontSize: 12,
        fontWeight: 600,
        formatter: '{c}亿'
      }
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart 2: Categories Distribution (Pie) ---
  var chart2 = echarts.init(document.getElementById('chart-categories'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      backgroundColor: 'rgba(15, 23, 42, 0.95)',
      borderColor: rule,
      borderWidth: 1,
      textStyle: { color: ink, fontSize: 13 },
      formatter: '{b}: {c}%'
    },
    legend: {
      orient: 'vertical',
      right: '5%',
      top: 'center',
      textStyle: { color: muted, fontSize: 13 },
      itemWidth: 14,
      itemHeight: 14,
      itemGap: 16
    },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      center: ['35%', '50%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 4,
        borderColor: 'rgba(15, 23, 42, 1)',
        borderWidth: 2
      },
      label: {
        show: false
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 14,
          fontWeight: 'bold',
          color: ink
        }
      },
      labelLine: { show: false },
      data: [
        { value: 79, name: '体育赛事', itemStyle: { color: accent } },
        { value: 8, name: '加密货币', itemStyle: { color: accent2 } },
        { value: 5, name: '政治选举', itemStyle: { color: accent3 } },
        { value: 4, name: '宏观经济', itemStyle: { color: '#fbbf24' } },
        { value: 4, name: '其他', itemStyle: { color: muted } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // --- Chart 3: Positioning Map (Scatter) ---
  var chart3 = echarts.init(document.getElementById('chart-positioning'), null, { renderer: 'svg' });
  
  var platforms = [
    // [用户体验(易用性), 合规程度, 平台名称, 交易量规模(气泡大小)]
    [8.5, 9.5, 'Kalshi', 80],
    [6.0, 7.0, 'Polymarket', 70],
    [7.5, 8.5, 'PredictIt', 15],
    [9.0, 2.0, 'Manifold Markets', 10],
    [5.5, 3.0, 'Opinion.trade', 40],
    [4.5, 2.5, 'Azuro Protocol', 8],
    [4.0, 3.5, 'Predict.fun', 12],
  ];

  chart3.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      backgroundColor: 'rgba(15, 23, 42, 0.95)',
      borderColor: rule,
      borderWidth: 1,
      textStyle: { color: ink, fontSize: 13 },
      formatter: function(params) {
        return '<strong>' + params.data[2] + '</strong><br/>' +
               '易用性：' + params.data[0] + '/10<br/>' +
               '合规度：' + params.data[1] + '/10';
      }
    },
    grid: {
      left: '5%',
      right: '5%',
      bottom: '10%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'value',
      name: '易用性 →',
      nameTextStyle: { color: muted, fontSize: 12, padding: [0, 0, 0, -30] },
      min: 0,
      max: 10,
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    yAxis: {
      type: 'value',
      name: '合规度 →',
      nameTextStyle: { color: muted, fontSize: 12, padding: [0, 0, 10, 0] },
      min: 0,
      max: 10,
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [{
      type: 'scatter',
      symbolSize: function(data) {
        return Math.sqrt(data[3]) * 4 + 10;
      },
      data: platforms.map(function(p) {
        var color = accent;
        if (p[2] === 'Kalshi') color = accent3;
        else if (p[2] === 'Polymarket') color = accent;
        else if (p[2] === 'Opinion.trade') color = accent2;
        else color = muted;
        return {
          value: [p[0], p[1], p[2], p[3]],
          itemStyle: {
            color: color,
            opacity: 0.8,
            shadowBlur: 10,
            shadowColor: color + '40'
          }
        };
      }),
      label: {
        show: true,
        formatter: function(params) {
          return params.data.value[2];
        },
        position: 'top',
        color: ink,
        fontSize: 11,
        fontWeight: 600
      },
      emphasis: {
        itemStyle: {
          opacity: 1,
          shadowBlur: 20
        }
      }
    },
    // 象限分割线
    {
      type: 'line',
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: {
          color: rule,
          type: 'dashed',
          width: 1
        },
        data: [
          { xAxis: 5 },
          { yAxis: 5 }
        ],
        label: { show: false }
      }
    }]
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // --- Chart 4: Market Share Evolution (Area) ---
  var chart4 = echarts.init(document.getElementById('chart-market-share'), null, { renderer: 'svg' });
  chart4.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      backgroundColor: 'rgba(15, 23, 42, 0.95)',
      borderColor: rule,
      borderWidth: 1,
      textStyle: { color: ink, fontSize: 13 }
    },
    legend: {
      data: ['Kalshi', 'Polymarket', 'Opinion.trade', '其他'],
      top: 0,
      textStyle: { color: muted, fontSize: 12 },
      itemWidth: 16,
      itemHeight: 8
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['2025年1月', '2025年6月', '2025年9月', '2025年12月', '2026年3月', '2026年6月'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 11 },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '市场份额（%）',
      nameTextStyle: { color: muted, fontSize: 12 },
      max: 100,
      axisLine: { show: false },
      axisLabel: { color: muted, fontSize: 11, formatter: '{value}%' },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [
      {
        name: 'Kalshi',
        type: 'line',
        stack: 'Total',
        smooth: true,
        lineStyle: { width: 0 },
        showSymbol: false,
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: accent3 + 'cc' },
              { offset: 1, color: accent3 + '33' }
            ]
          }
        },
        data: [21, 35, 62, 55, 52, 58]
      },
      {
        name: 'Polymarket',
        type: 'line',
        stack: 'Total',
        smooth: true,
        lineStyle: { width: 0 },
        showSymbol: false,
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: accent + 'cc' },
              { offset: 1, color: accent + '33' }
            ]
          }
        },
        data: [79, 60, 35, 38, 40, 32]
      },
      {
        name: 'Opinion.trade',
        type: 'line',
        stack: 'Total',
        smooth: true,
        lineStyle: { width: 0 },
        showSymbol: false,
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: accent2 + 'cc' },
              { offset: 1, color: accent2 + '33' }
            ]
          }
        },
        data: [0, 0, 0, 5, 6, 7]
      },
      {
        name: '其他',
        type: 'line',
        stack: 'Total',
        smooth: true,
        lineStyle: { width: 0 },
        showSymbol: false,
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: muted + '88' },
              { offset: 1, color: muted + '22' }
            ]
          }
        },
        data: [0, 5, 3, 2, 2, 3]
      }
    ]
  });
  window.addEventListener('resize', function() { chart4.resize(); });

})();
