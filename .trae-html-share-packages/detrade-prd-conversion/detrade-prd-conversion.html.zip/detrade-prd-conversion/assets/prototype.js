(function() {
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  var navButtons = qsa('.proto-nav .btn');
  var screens = qsa('.screen');
  var modal = qs('#proto-modal');
  var modalTitle = qs('#proto-modal-title');
  var modalBody = qs('#proto-modal-body');

  function showScreen(id) {
    screens.forEach(function(s) { s.classList.toggle('active', s.id === id); });
    navButtons.forEach(function(b) { b.classList.toggle('active', b.getAttribute('data-go') === id); });
  }

  function showModal(title, body) {
    if (!modal) return;
    modalTitle.textContent = title || '提示';
    modalBody.textContent = body || '';
    modal.classList.add('show');
  }

  function hideModal() {
    if (!modal) return;
    modal.classList.remove('show');
  }

  // Nav
  navButtons.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var id = btn.getAttribute('data-go');
      showScreen(id);
    });
  });

  // Action handlers
  document.addEventListener('click', function(e) {
    var t = e.target;
    if (!t) return;
    var act = t.getAttribute('data-action');
    if (!act) return;

    if (act === 'go-demo') {
      showScreen('s-demo');
      return;
    }
    if (act === 'go-signup') {
      showScreen('s-signup');
      return;
    }
    if (act === 'trust') {
      showModal('资质与安全（示意）', '这里建议展示：主体与牌照信息、资金安全说明、储备证明入口、客服入口。关键是“可验证”，并且不要在注册关键步骤强迫用户阅读长文。');
      return;
    }

    if (act === 'demo-win') {
      showModal('触发点：首次盈利', '你刚刚在 Demo 获得盈利。注册即可保存战绩、解锁额外体验金，并获得首充奖励领取资格。');
      // 同时把导航切到触发点页面，便于演示
      showScreen('s-trigger');
      return;
    }
    if (act === 'demo-3orders') {
      showModal('触发点：完成 3 笔交易', '你已完成 3 笔 Demo 交易。注册即可继续体验更多品类/更多次数，并保存交易记录。');
      showScreen('s-trigger');
      return;
    }
    if (act === 'demo-loss') {
      showModal('触发点：连续亏损', '检测到连续亏损。注册后可开启新手保护/风控提示/复盘建议，帮助你降低亏损。');
      showScreen('s-trigger');
      return;
    }

    if (act === 'later') {
      showModal('稍后再说（示意）', '在真实产品中，这里可选择“继续试玩（剩余次数 X）”或“注册领取”。为了不打断体验，建议给出可见的剩余次数/时长。');
      showScreen('s-demo');
      return;
    }

    if (act === 'send-otp') {
      showModal('验证码已发送（示意）', '提示建议包含：可能在垃圾箱、60 秒后可重发、无法收到可换邮箱或联系客服。');
      return;
    }
    if (act === 'signup-ok') {
      showModal('注册成功（示意）', '下一步直接引导首充任务：展示小额档位 + 奖励规则卡片 + 进度条。');
      showScreen('s-deposit');
      return;
    }

    if (act === 'deposit-10' || act === 'deposit-20' || act === 'deposit-50') {
      var amt = act === 'deposit-10' ? '$10' : (act === 'deposit-20' ? '$20' : '$50');
      showModal('首充提交（示意）', '你选择了 ' + amt + '。真实产品中这里会进入支付方式选择与确认页，并在成功后返回交易页，同时标记任务进度完成。');
      return;
    }

    if (act === 'close-modal') {
      hideModal();
      return;
    }
  });

  // Click outside modal to close
  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) hideModal();
    });
  }
})();

